#ifndef DATA_H
#define DATA_H

#include "./user/user.h"            // Include user-related functionality
#include "./clerk/clerk.h"          // Include clerk-related functionality
#include "./customer/customer.h"    
#include "./customer/customer.h"    // Include customer-related functionality
#include "./account.h"              // Include account-related functionality
#include "./transaction.h"          // Include transaction-related functionality

#endif


            